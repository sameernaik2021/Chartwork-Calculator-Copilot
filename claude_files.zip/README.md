# Chartwork Calculator

A single-file, zero-dependency web app that performs the everyday sums of marine chartwork: speed-distance-time, course and distance between positions, dead-reckoning, compass error, current triangles and closest point of approach (CPA).

It replaces the dividers, parallel rules and calculator on a navigation exercise. It is meant for **study, checking and experimentation** (Nautical Science, deck-officer subjects, data-science experiments on navigation data). It is **not** a certified navigation aid.

- Runs by double-clicking `chartwork-calculator.html`. No build step, no server, no network.
- About 27 KB of HTML, CSS and JavaScript in one file.
- The calculation layer is pure JavaScript, so it can also be reused in Node for batch work.
- 33 automated tests (21 unit, 12 integration), all passing, no test dependencies.

---

## Table of contents

1. [Quick start](#1-quick-start)
2. [Project layout](#2-project-layout)
3. [Architecture overview](#3-architecture-overview)
4. [Feature guide and worked examples](#4-feature-guide-and-worked-examples)
5. [Public API and data contracts](#5-public-api-and-data-contracts)
6. [UI contract (element ids)](#6-ui-contract-element-ids)
7. [The maths: complex logic explained](#7-the-maths-complex-logic-explained)
8. [Design decisions](#8-design-decisions)
9. [Validation rules and error messages](#9-validation-rules-and-error-messages)
10. [Testing](#10-testing)
11. [Usage snippets](#11-usage-snippets)
12. [Environment and dependencies](#12-environment-and-dependencies)
13. [Limitations](#13-limitations)
14. [Extending the project](#14-extending-the-project)
15. [Troubleshooting](#15-troubleshooting)

---

## 1. Quick start

### Use the app

1. Download `chartwork-calculator.html`.
2. Open it in any modern browser (Chrome, Edge, Firefox, Safari; desktop or mobile).
3. Pick a tab, fill in the fields, press **Calculate**. **Reset** clears that card.

Optional local server (only needed if your browser blocks something on `file://`, which it normally does not):

```bash
python3 -m http.server 8080
# then open http://localhost:8080/chartwork-calculator.html
```

### Run the tests

Requires Node.js 18 or newer. Nothing to install.

```bash
node --test                 # everything (33 tests)
node --test tests/unit.test.js
node --test tests/integration.test.js
# or through npm scripts
npm test
```

Expected result:

```
# tests 33
# pass 33
# fail 0
```

### 60-second smoke test

Open the page, go to **Set & Drift**, and enter: track `0`, ship speed `10`, set `90`, drift `5`. You should see **Course to steer 330.0°**, **30.0° to port of track**, **Speed over ground 8.66 kn**. Then press **Run self-test** at the bottom of the page: it should report `All 21 tests passed`.

---

## 2. Project layout

```
chartwork-calculator/
├── chartwork-calculator.html   # The whole application (HTML + CSS + JS)
├── package.json                # Scripts only; no dependencies
├── README.md                   # This file
└── tests/
    ├── helpers.js              # Loads code out of the HTML file; fake DOM for UI tests
    ├── unit.test.js            # 21 tests of the pure calculation functions
    └── integration.test.js     # 12 tests of markup + UI handlers + formatting
```

Inside `chartwork-calculator.html`:

| Region | Purpose |
|---|---|
| `<style>` | Theme tokens (light and dark), layout, components |
| `<body>` | Six tab sections, each made of cards with inputs and a result panel |
| `<script>` between `/*CORE*/` and `/*END*/` | **Pure calculation layer**, no DOM access |
| `<script>` after `/*END*/` | UI layer: input reading, validation, formatting, event wiring |

The two marker comments are part of the contract: the tests and your own Node scripts use them to lift the core out of the HTML file. Do not remove them.

---

## 3. Architecture overview

```
 ┌───────────────────────────── chartwork-calculator.html ─────────────────────────────┐
 │                                                                                    │
 │   Markup (tabs, cards, inputs, result panels)                                      │
 │        │  ids                                                                      │
 │        ▼                                                                           │
 │   UI layer ── val/req/opt ─► readPos ─► handlers.calcXxx ─► run(id, fn)            │
 │        ▲          (parse + validate)      (one per button)      │                  │
 │        │                                                        ▼                  │
 │   rows()/fail()  ◄── fmtBrg / fmtPos / fmtMin / fmtTime ◄── result rows            │
 │                                                                                    │
 │   ─────────────────────────── /*CORE*/ (pure, no DOM) ───────────────────────────  │
 │   solveDST  courseDist  drPos  compassConv  steer  resultant  cpaCalc  selfTest    │
 │   helpers: nd, nb, mp                                                              │
 └────────────────────────────────────────────────────────────────────────────────────┘
```

**Data flow for one calculation** (example: *Course & Distance*):

1. The user presses **Calculate**. The button carries `data-do="calcCD"`.
2. `handlers.calcCD` runs inside `run("r_cd", fn)`, which wraps everything in `try/catch`.
3. `readPos` reads the degree, minute and hemisphere inputs and validates each one (`req`, `optZero`). The result is a plain object `{ lat, lon }` in signed decimal degrees.
4. `courseDist(a, b)` (pure) returns a plain result object in numbers only.
5. The handler turns the numbers into display rows (`["Mercator course", "090.0°"]`).
6. `rows()` writes them into the result panel; if anything threw, `fail()` shows the message instead.

**Layering rule:** the core never touches the DOM and never formats text; the UI never does maths. That is what makes the core unit-testable and reusable in Node.

---

## 4. Feature guide and worked examples

All directions are **degrees true** unless the label says magnetic or compass. Speeds are knots, distances are nautical miles (nm).

### 4.1 Speed / Distance / Time

Fill exactly two of speed, distance and time (hours and/or minutes); leave the third blank.

| Input | Output |
|---|---|
| Speed 12 kn, distance 30 nm | Time 2 h 30 min (2.500 h) |
| Speed 10 kn, time 1 h 30 min | Distance 15.00 nm |
| Distance 240 nm, time 12 h | Speed 20.00 kn |

### 4.2 Course & Distance

Enter departure and destination as degrees, minutes and hemisphere. Optionally enter a speed for an ETA.

Outputs: D. lat, D. long, plane-sailing departure, D.M.P., **Mercator course and distance**, **plane-sailing course and distance**, **great-circle initial course and distance**, and the steaming time along the rhumb line.

Example: 50° 00′ N 000° 00′ E to 50° 00′ N 001° 00′ E at 10 kn gives Mercator course 090.0°, distance 38.6 nm, D. long 60.0′ E, steaming time 3 h 51 min.

### 4.3 DR Position

Enter a start position, a true course and a distance run. The app returns D. lat, D. long, departure and the latitude and longitude arrived at.

Example: 60° N 000° E, course 090°, distance 60 nm gives longitude 002° 00.0′ E (60 nm at 60° N is 120′ of longitude).

### 4.4 Compass Error

Enter a direction, say whether it is true, magnetic or compass, and give variation and deviation with E/W names. Blank variation or deviation counts as zero.

Example: true 090°, variation 5° W, deviation 2° E gives magnetic 095.0°, compass 093.0°, compass error 3.0° W.

Sign convention: easterly variation or deviation is **added** going from compass to magnetic to true, and **subtracted** going the other way; westerly is the opposite.

### 4.5 Set & Drift

Two cards:

- **Course to steer.** Given desired track, ship speed through water, set and drift of the current, it returns the heading to steer, the correction (port or starboard of track) and the speed over ground. An optional distance also returns the time.
- **Track made good.** Given course steered, ship speed, set and drift, it returns the resulting track and speed over ground.

Example: track 000°, speed 10 kn, current setting 090° at 5 kn gives steer 330.0°, 30.0° to port of track, SOG 8.66 kn.

### 4.6 CPA / TCPA

Enter own course and speed, and the target's true bearing, range, course and speed. If the vessels are closing, you get CPA, time to CPA, and the bearing of the target at CPA, plus the relative course and speed. If they are opening, the panel says so.

Example: own 000° at 10 kn; target bearing 090° at 5 nm, course 270° at 10 kn gives CPA 3.54 nm in 15 min.

---

## 5. Public API and data contracts

This project has **no HTTP endpoints, no server and no database**. Everything runs in the browser. The "endpoints" are therefore the **pure functions in the core** (the API you can call from Node or from your own page) and the **UI handlers** (section 6).

Conventions for every function:

- Angles in and out are **degrees**. Bearings and courses out are normalised to `[0, 360)`.
- Latitude is signed decimal degrees (**north +**), longitude is signed decimal degrees (**east +**).
- Distances are nm, speeds are kn, times are hours.
- Functions are pure and synchronous. On invalid input they **throw `Error`** with a human-readable message (see section 9).
- Inputs are assumed to be finite numbers already; range validation of raw form input is the UI layer's job.

### Type shapes

```ts
type Pos = { lat: number; lon: number };   // lat in [-90, 90], lon in [-180, 180]
```

### `solveDST(s, d, t)`

Exactly one argument must be `NaN`; that one is solved.

| Param | Unit | Notes |
|---|---|---|
| `s` | kn | `NaN` to solve for speed |
| `d` | nm | `NaN` to solve for distance |
| `t` | h | `NaN` to solve for time |

Returns `{ s, d, t }`. Throws if the number of `NaN`s is not exactly one, if solving for time with `s <= 0`, or for speed with `t <= 0`.

```js
solveDST(12, 30, NaN)   // { s: 12, d: 30, t: 2.5 }
```

### `courseDist(a, b)`

| Param | Type |
|---|---|
| `a` | `Pos` departure |
| `b` | `Pos` destination |

Returns either `{ same: true }` (identical positions) or:

| Field | Meaning | Unit |
|---|---|---|
| `same` | `false` | |
| `dlat` | change of latitude, north +  | arc-minutes |
| `dlon` | change of longitude (shortest way), east + | arc-minutes |
| `dmp` | difference of meridional parts | arc-minutes |
| `merC`, `merD` | Mercator (rhumb-line) course, distance | °, nm |
| `dep` | departure by mean latitude | nm |
| `plC`, `plD` | plane-sailing course, distance | °, nm |
| `gcC`, `gcD` | great-circle **initial** course, distance | °, nm |

Throws if either latitude is beyond 89°.

### `drPos(p, c, d)`

| Param | Type | Notes |
|---|---|---|
| `p` | `Pos` | start |
| `c` | number | true course, degrees |
| `d` | number | distance run, nm |

Returns `{ lat, lon, dlat, dlon, dep }` where `lat`, `lon` are the arrival position (degrees, longitude wrapped to `[-180, 180)`), `dlat`, `dlon` are in arc-minutes, and `dep` (nm) is `d·sin(c)`. Throws if the start or the arrival latitude is beyond 89°.

### `compassConv(dir, type, vr, dv)`

| Param | Notes |
|---|---|
| `dir` | the known direction, degrees |
| `type` | `"T"` true, `"M"` magnetic or `"C"` compass: what `dir` is |
| `vr` | variation, **signed, east positive** |
| `dv` | deviation, **signed, east positive** |

Returns `{ t, m, c }`, all in `[0, 360)`. Relations: `T = M + vr`, `M = C + dv`.

### `steer(track, V, setDir, rate)`

| Param | Notes |
|---|---|
| `track` | desired track over the ground, °T |
| `V` | ship speed through the water, kn (must be above 0) |
| `setDir` | direction the current flows **towards**, °T |
| `rate` | current rate (drift), kn |

Returns `{ heading, sog, wca }`: heading to steer (°T), speed over ground (kn), and wind-and-current correction `nd(heading - track)` in `[-180, 180)` (negative means steer to **port** of the track, positive to **starboard**). Throws if the current's cross-track component exceeds `V`, or if the ship cannot make headway along the track.

### `resultant(course, V, setDir, rate)`

Vector sum of ship and current. Returns `{ track, sog }`. `track` is `NaN` if the ground speed is effectively zero.

### `cpaCalc(oc, os, brg, rng, tc, ts)`

| Param | Meaning |
|---|---|
| `oc`, `os` | own course (°T), own speed (kn) |
| `brg`, `rng` | target true bearing (°), range (nm) |
| `tc`, `ts` | target course (°T), speed (kn) |

Returns one of:

```js
{ still: true, cpa: rng }                        // no relative motion
{ still: false, rs, rc, t, cpa, closing: false } // opening; t <= 0 (hours ago)
{ still: false, rs, rc, t, cpa, closing: true, brgCpa } // closing; t > 0 hours
```

`rs` and `rc` are the target's relative speed (kn) and relative course (°T). `brgCpa` is the true bearing of the target from own ship at CPA.

### Helpers

| Function | Behaviour |
|---|---|
| `nb(x)` | normalise to `[0, 360)` |
| `nd(x)` | normalise to `[-180, 180)` (so `nd(180) === -180`, which is the same meridian) |
| `mp(lat)` | meridional parts of a latitude in arc-minutes, spherical earth |
| `selfTest()` | returns an array of `"PASS ..."` / `"FAIL ..."` strings (21 checks) |

---

## 6. UI contract (element ids)

Handlers are registered by `data-do` attributes on the **Calculate** buttons. Each reads the listed input ids and writes to one result panel.

| Handler | Inputs read | Result panel |
|---|---|---|
| `calcDST` | `dst_s`, `dst_d`, `dst_h`, `dst_m` | `r_dst` |
| `calcCD` | `cd1_*`, `cd2_*` (position), `cd_s` | `r_cd` |
| `calcDR` | `dr_*` (position), `dr_c`, `dr_d` | `r_dr` |
| `calcCMP` | `cm_dir`, `cm_type`, `cm_var`, `cm_varh`, `cm_dev`, `cm_devh` | `r_cmp` |
| `calcSteer` | `st_track`, `st_speed`, `st_set`, `st_rate`, `st_dist` | `r_st` |
| `calcResultant` | `rs_course`, `rs_speed`, `rs_set`, `rs_rate` | `r_rs` |
| `calcCPA` | `cp_oc`, `cp_os`, `cp_b`, `cp_r`, `cp_tc`, `cp_ts` | `r_cpa` |

Position groups (`prefix` is `cd1`, `cd2` or `dr`) are generated by `buildPos(hostId, prefix)`:

| Id | Meaning | Range |
|---|---|---|
| `<prefix>_latd`, `<prefix>_latm` | latitude degrees, minutes | 0 to 90, 0 to 59.99 |
| `<prefix>_lath` | hemisphere select, value `1` = N, `-1` = S | |
| `<prefix>_lond`, `<prefix>_lonm` | longitude degrees, minutes | 0 to 180, 0 to 59.99 |
| `<prefix>_lonh` | hemisphere select, value `1` = E, `-1` = W | |

Result panels use the classes `result on` (success) or `result err on` (error). Each success row is `<div class="row"><span>label</span><b>value</b></div>`. Panels have `aria-live="polite"` so screen readers announce updates.

### Display formats

| Kind | Format | Example |
|---|---|---|
| Bearing | 3 digits and one decimal, `°` | `090.0°` (360 is shown as 000.0) |
| Latitude / longitude | degrees, decimal minutes, hemisphere | `01° 30.0′ N`, `002° 00.0′ E` |
| Arc change | minutes and direction | `60.0′ S` |
| Time | hours and minutes | `2 h 30 min` |

---

## 7. The maths: complex logic explained

### 7.1 Meridional parts and Mercator sailing

On a Mercator chart, latitude is stretched so that rhumb lines are straight. The stretched latitude ("meridional parts") for a sphere is

```
MP(φ) = (10800 / π) · ln( tan(π/4 + φ/2) )      [arc-minutes]
```

For a leg from A to B:

```
D.lat = (φB − φA) · 60              [minutes]
D.long = wrap(λB − λA) · 60         [minutes, shortest way]
D.M.P. = MP(φB) − MP(φA)
course = atan2(D.long, D.M.P.)      [true course, all four quadrants]
distance = |D.lat| / |cos(course)|
```

`atan2` handles the quadrant automatically, so there is no manual N/S/E/W rule to apply. Special case: if `D.M.P.` is (near) zero the leg runs along a parallel and the distance is `|D.long| · cos(φ)`, which avoids dividing by a `cos` that is zero.

### 7.2 Plane sailing and great circle

- **Plane sailing** flattens the leg into a right triangle using the mean latitude: `dep = D.long · cos(φmean)`, `course = atan2(dep, D.lat)`, `distance = √(dep² + D.lat²)`. Fine for short legs; the tests confirm it agrees with Mercator to within 0.05 nm on a 20-mile leg.
- **Great circle** uses the haversine formula for distance and the standard forward-azimuth formula for the *initial* course. The great-circle course changes along the route, so only the initial course is reported. The great-circle distance is never longer than the rhumb line (tested).

### 7.3 Dead reckoning (inverse of 7.1)

```
D.lat = d · cos(C)              φ2 = φ1 + D.lat / 60
D.long = D.M.P. · tan(C)        [minutes], with D.M.P. = MP(φ2) − MP(φ1)
λ2 = wrap(λ1 + D.long / 60)
```

When `D.lat` is (near) zero (an east-west run) the formula would multiply zero by infinity, so the code uses parallel sailing instead: `D.long = d · sin(C) / cos(φ1)`. A seeded 200-case round-trip test (`drPos` then `courseDist`) recovers the original course and distance to within rounding error.

### 7.4 Longitude wrap and the date line

`nd(x) = ((x + 180) mod 360 + 360) mod 360 − 180` folds any difference of longitude into `[-180, 180)`. Sailing from 170° E to 170° W therefore yields `D.long = +1200′` (20° east), not `−20400′`.

### 7.5 Course to steer (current triangle solved with vectors)

Rather than the traditional sine rule (which needs case analysis for head, following and beam currents) the code uses vectors:

1. Let `t` be the unit vector along the desired track and `n` the unit vector at right angles to it (to starboard).
2. Current vector `c = rate · (sin set, cos set)`.
3. The current's sideways component is `p = c · n`. The ship must cancel it, so it needs `|p| ≤ V`; otherwise no heading holds the track (error).
4. The ship's along-track speed through the water is `a = √(V² − p²)`.
5. Ship velocity through the water is `a·t − p·n`; the heading is its bearing.
6. Speed over ground is `a + c · t`. If that is not positive the ship cannot make headway.

The same formulation works for any angle between track and current, including exact head and following currents, with no special cases.

### 7.6 Track made good

Straight vector addition: `ground = V·(sin C, cos C) + rate·(sin set, cos set)`; track is its bearing, SOG its length. A seeded 150-case test verifies that `steer` and `resultant` are exact inverses.

### 7.7 CPA and TCPA (relative motion)

Working in a frame fixed on own ship:

```
p  = range · (sin bearing, cos bearing)      target position
vr = v_target − v_own                        relative velocity
t  = − (p · vr) / |vr|²                      hours until closest approach
CPA = | p + vr · t |        if t > 0
```

If `t ≤ 0` the target is already opening; the "CPA" reported is the present range and the panel says how long ago the closest point was. If `|vr|` is effectively zero the range never changes.

---

## 8. Design decisions

| Decision | Why |
|---|---|
| **One HTML file, no framework, no build** | Easy to hand to a student, email, host anywhere, and open years from now. There is nothing to break. |
| **Pure core between `/*CORE*/` and `/*END*/` markers** | Testable without a browser; reusable in Node for data-science work; the UI cannot corrupt the maths. |
| **Tests load the shipped HTML, not a copy** | The tests can never drift from the code that users actually run. |
| **Fake DOM inside the test helper instead of jsdom** | Keeps the project dependency-free, and the tests run in milliseconds. |
| **`atan2` instead of quadrant rules** | Removes a whole class of "which way do I add 180" bugs. |
| **Vector method for currents** | One code path covers every current direction; sine-rule versions need special cases. |
| **Spherical earth, 1′ of latitude = 1 nm** | Matches how chartwork is taught and examined. See limitations for the ellipsoid difference. |
| **Degrees, decimal minutes on input and output** | The format a navigator reads off a chart; avoids decimal-degree conversions by hand. |
| **Errors are messages, not silent guesses** | Missing, out-of-range or physically impossible input always produces a clear, specific message. |
| **Reference angles normalised in one place (`nb`, `nd`)** | Consistent 0 to 360 output everywhere, and consistent handling of the 180° meridian. |
| **`var` and function declarations, no modules** | Works from `file://` in every browser (ES modules are blocked there by some browsers). |
| **Theme via CSS custom properties, light and dark** | Follows the device setting; contrast stays readable outdoors and at night. |
| **Result values are built from numbers only, then written with `innerHTML`** | No user-supplied text is ever inserted as markup, so there is no injection surface; error text uses `textContent`. |

---

## 9. Validation rules and error messages

### Input validation (UI layer)

| Field | Allowed | Blank means |
|---|---|---|
| Latitude degrees | 0 to 90 | error: required |
| Longitude degrees | 0 to 180 | error: required |
| Minutes | 0 to 59.99 | 0 |
| Courses, bearings, set | 0 to 360 | error: required |
| Speeds, drifts, ranges, distances | 0 and above | error: required |
| Optional fields (ETA speed, distance) | as above | ignored |
| Variation, deviation | 0 to 90 | 0 |

### Messages you may see

| Message | Cause |
|---|---|
| `<Field> is required.` | Empty or non-numeric input |
| `<Field> must be between A and B.` | Out of range |
| `Fill exactly two of Speed, Distance and Time, and leave one empty.` | Zero, one, or three of the DST fields left blank |
| `Speed must be above zero to find time.` / `Time must be above zero to find speed.` | Division by zero avoided |
| `Latitudes must be within 89° for rhumb-line sailing.` | Mercator stretch becomes unbounded at the poles |
| `Resulting latitude is beyond 89°; Mercator sailing does not apply.` | DR run ends near a pole |
| `Current is too strong: the ship cannot hold that track at this speed.` | Cross-track current exceeds ship speed |
| `The ship cannot make headway along that track.` | Head current is at least as fast as the ship |
| `Ship speed must be above zero.` | Steering with a stopped ship |

---

## 10. Testing

### Overview

| File | Tests | What it covers |
|---|---|---|
| `tests/unit.test.js` | 21 | Every core function: normal cases, quadrants, wrap-around, invalid input, and seeded property tests |
| `tests/integration.test.js` | 12 | Markup integrity, id wiring, handler behaviour, number formatting, hemisphere selects, error panels |

Uses only `node:test` and `node:assert` (built into Node 18+).

### Unit test highlights

- **Reference values:** due-north leg is exactly 60 nm; a 50° N parallel run of 1° is 60·cos 50° = 38.57 nm; `MP(45°) ≈ 3030.0′`.
- **Quadrants:** SW and SE courses fall in the correct 90° bands.
- **Date line:** 170° E to 170° W gives `+1200′`; the reverse gives `−1200′`.
- **Great circle:** 90° of equator is 5400 nm; never longer than the rhumb line.
- **Property tests (seeded, reproducible):**
  - 200 random `drPos → courseDist` round trips.
  - 100 random true/magnetic/compass round trips.
  - 150 random `steer → resultant` round trips.
- **CPA:** head-on, crossing (CPA 3.54 nm), parallel (no relative motion), opening (negative TCPA), converging at an angle.

### Integration test highlights

- The file has **no external URLs, scripts or stylesheets** (guards the "works offline" promise).
- All six `data-tab` targets exist, all seven `data-do` handlers exist as functions, and **every input id the script reads exists in the markup** (catches typos in ids).
- Full panel behaviour for each tab, including S and W hemispheres, blank minutes, identical positions, and error panels for bad input.

### How the integration tests work

`tests/helpers.js` executes the script from the HTML in Node's `vm` module against a minimal fake `document` whose elements are created on demand. It exposes:

```js
const { loadCore, loadUI } = require("./tests/helpers");

const nav = loadCore();            // pure functions only
const ui  = loadUI();              // full script + fake DOM
ui.set({ dst_s: 12, dst_d: 30 });  // fill inputs by id
ui.call("calcDST");                // press "Calculate"
ui.text("r_dst");                  // "Speed 12.00 kn Distance 30.00 nm Time 2 h 30 min (2.500 h)"
ui.isError("r_dst");               // false
```

### In-browser self-test

The **Run self-test** button at the bottom of the app runs `selfTest()` (21 checks of the core) inside the user's own browser, which is handy after copying the file to a new device or hosting it somewhere new.

### Adding a test

```js
// tests/unit.test.js
test("my new case", () => {
  const r = C.courseDist({ lat: 0, lon: 0 }, { lat: 0, lon: 10 });
  near(r.merD, 600, 1e-6);
});
```

---

## 11. Usage snippets

### 11.1 Use the core from Node

```js
const { loadCore } = require("./tests/helpers");
const nav = loadCore();

// Southampton area to New York, rhumb line and great circle
console.log(nav.courseDist({ lat: 50.5, lon: -1.0 }, { lat: 40.7, lon: -74.0 }));
// { same:false, dlat:-588, dlon:-4380, dmp:-843.59,
//   merC:259.1, merD:3109.07, plC:259.14, plD:3120.43, gcC:288.58, gcD:2993.81, ... }

// DR: 240 nm on course 075° from 35° N 040° W
console.log(nav.drPos({ lat: 35, lon: -40 }, 75, 240));
// { lat:36.0353, lon:-35.2529, dlat:62.1166, dlon:284.8238, dep:231.8222 }

// Current: track 090°, 14 kn, current setting 180° at 2.5 kn
console.log(nav.steer(90, 14, 180, 2.5));
// { heading:79.713, sog:13.775, wca:-10.287 }   (steer 079.7°T, 10.3° to port)

// CPA: own 000° 12 kn, target bearing 045° 8 nm, course 270° 10 kn
console.log(nav.cpaCalc(0, 12, 45, 8, 270, 10));
// { still:false, rs:15.62, rc:219.806, t:0.51, cpa:0.724, closing:true, brgCpa:129.806 }

// Compass: compass course 270°, variation 3° E, deviation 2° W
console.log(nav.compassConv(270, "C", 3, -2));
// { t:271, m:268, c:270 }

// Speed, distance, time
console.log(nav.solveDST(NaN, 240, 12));   // { s:20, d:240, t:12 }
```

### 11.2 Batch experiment (data-science style)

How does drift change the heading and speed over ground for a 12 kn ship on track 000° with an easterly current?

```js
const { loadCore } = require("./tests/helpers");
const nav = loadCore();

console.log("drift_kn,heading_deg,sog_kn");
for (let rate = 0; rate <= 6; rate += 2) {
  const s = nav.steer(0, 12, 90, rate);
  console.log([rate, s.heading.toFixed(1), s.sog.toFixed(2)].join(","));
}
```

Output:

```
drift_kn,heading_deg,sog_kn
0,0.0,12.00
2,350.4,11.83
4,340.5,11.31
6,330.0,10.39
```

Save with `node experiment.js > drift.csv` and load the CSV into pandas, R or a spreadsheet.

### 11.3 Handle errors in a batch

```js
for (const rate of [2, 8, 12, 14]) {
  try {
    const s = nav.steer(0, 12, 90, rate);
    console.log(rate, s.heading.toFixed(1));
  } catch (e) {
    console.log(rate, "no solution:", e.message);   // rate 14 > ship speed 12
  }
}
```

### 11.4 Reuse the core in your own web page

1. Copy everything between `/*CORE*/` and `/*END*/` into a `<script>` in your page.
2. Call the functions from your own code:

```html
<script>
  /* paste the core here */
  const r = courseDist({ lat: 30, lon: 10 }, { lat: 32, lon: 14 });
  document.body.textContent = r.merC.toFixed(1) + "° / " + r.merD.toFixed(1) + " nm";
</script>
```

### 11.5 Drive the UI programmatically (browser console)

```js
document.getElementById("dst_s").value = 12;
document.getElementById("dst_d").value = 30;
handlers.calcDST();
document.getElementById("r_dst").innerText;
```

### 11.6 Verify by hand

Quick cross-check of a DR answer with a calculator: start 60° N, run 60 nm on 090°. Departure = 60 nm, so D.long = 60 / cos 60° = 120′ = 2° E. The app shows `Longitude in 002° 00.0′ E`.

---

## 12. Environment and dependencies

| Item | Requirement |
|---|---|
| Running the app | Any current browser with JavaScript enabled. No network access at any time. |
| Running tests | Node.js **18 or newer** (tested on Node 22). |
| Runtime dependencies | **None** |
| Dev dependencies | **None** (uses built-in `node:test`, `node:assert`, `node:vm`, `node:fs`) |
| Package manager | Not needed (`package.json` exists only for the script shortcuts) |
| External assets | None: no CDN scripts, fonts, images or stylesheets. The font stack is `Georgia, "Times New Roman", serif`. |
| OS | Anything that runs a browser and, for tests, Node |

`package.json` scripts:

| Script | Command |
|---|---|
| `npm test` | `node --test` |
| `npm run test:unit` | `node --test tests/unit.test.js` |
| `npm run test:integration` | `node --test tests/integration.test.js` |
| `npm run serve` | `python3 -m http.server 8080` |

Continuous integration example (GitHub Actions):

```yaml
name: tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: node --test
```

---

## 13. Limitations

- **Spherical earth.** Real charts use an ellipsoid; over long rhumb-line legs the answers can differ from ellipsoidal tables by a small fraction of a percent. Fine for coursework, not for passage-critical figures.
- **Poles.** Latitudes beyond 89° are rejected for rhumb-line work.
- **Great circle** reports only the initial course and total distance; it does not compute waypoints or a vertex.
- **CPA** assumes both ships hold constant course and speed and uses true bearings. It does not apply safety limits or alarms.
- **Currents** are treated as constant over the leg. There is no tidal-stream table, leeway or wind component.
- **No persistence.** Nothing is saved between sessions; reloading clears the fields.
- **Not a certified navigation aid.** Use official publications and equipment for real navigation.

---

## 14. Extending the project

1. **Add a function** to the core block (pure, degrees in and out, throw on bad input) and a unit test for it.
2. **Add a card**: copy an existing `.card` inside a `<section class="tab">`, give inputs unique ids, and add a `data-do="calcNew"` button plus a `<div class="result" id="r_new">`.
3. **Add a handler**: add `calcNew: function () { run("r_new", function () { ... return [[label, value], ...]; }); }` to `handlers`. Use `req`/`opt`/`optZero` to read inputs and the `fmt*` helpers to display them.
4. **Add an integration test** that sets ids with `ui.set`, calls `ui.call("calcNew")` and checks `ui.text("r_new")`. The id-wiring test will catch any misspelled id automatically.
5. **Ideas:** ellipsoidal meridional parts, running fix and set-and-drift from two fixes, wind and leeway, tidal height and time calculations, unit toggles (km/h, metres), CSV import for batch legs.

---

## 15. Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Nothing happens on **Calculate** | JavaScript is disabled or blocked; enable it. Check the browser console for errors. |
| Tests say `Cannot find module` | Run from the project folder (`cd chartwork-calculator`), and use `node --test` rather than `node --test tests/` (Node 22 treats a folder argument as a module path). |
| Tests fail after editing the HTML | Make sure the `/*CORE*/` and `/*END*/` markers are still present, and that no comment inside the script contains a stray `*/`. |
| Layout looks unstyled | The `<style>` block was edited or truncated; restore from the original. |
| Colours look wrong | The page follows the system light or dark setting; change the device theme or force one with `data-theme="light"` or `"dark"` on `<html>`. |
| "Fill exactly two of Speed, Distance and Time" | You filled one or all three fields. Leave exactly one blank. |
| Longitude answer looks like the wrong sign | Check the E/W and N/S selectors; longitudes and latitudes are entered as unsigned degrees with a hemisphere. |

---

## Licence

MIT. Use, modify and share freely. No warranty; see the limitations above.
