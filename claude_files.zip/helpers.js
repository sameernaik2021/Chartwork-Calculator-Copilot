"use strict";
// Loads the calculator source straight out of chartwork-calculator.html so the
// tests always exercise the shipped code (no copy, no build step, no dependencies).
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const HTML_PATH = path.join(__dirname, "..", "chartwork-calculator.html");
const html = fs.readFileSync(HTML_PATH, "utf8");
const script = /<script>([\s\S]*?)<\/script>/.exec(html)[1];

// Pure calculation layer only (the block between the CORE and END marker comments). No DOM needed.
function loadCore() {
  const core = script.split("/*CORE*/")[1].split("/*END*/")[0];
  const ctx = vm.createContext({});
  vm.runInContext(core, ctx);
  return ctx;
}

/**
 * Whole script (core + UI handlers) run against a tiny fake DOM.
 * Every element id is created on demand; <select> ids get their default values.
 * Returns { ctx, els, set(values), call(handlerName) }.
 */
function loadUI() {
  const els = {};
  function el(id) {
    if (!els[id]) {
      let v = "";
      if (/_(lath|lonh)$/.test(id)) v = "1";
      else if (/^cm_(varh|devh)$/.test(id)) v = "E";
      else if (id === "cm_type") v = "T";
      const o = { value: v, className: "", innerHTML: "" };
      // textContent replaces the element's content, exactly like the real DOM
      Object.defineProperty(o, "textContent", {
        get() { return o.innerHTML.replace(/<[^>]+>/g, ""); },
        set(x) { o.innerHTML = String(x); }
      });
      els[id] = o;
    }
    return els[id];
  }
  const document = {
    readyState: "loading",            // keeps init() from running
    addEventListener() {},
    getElementById: el,
    querySelectorAll: () => []
  };
  const ctx = vm.createContext({ document });
  vm.runInContext(script, ctx);
  return {
    ctx, els, el,
    set(values) { for (const k of Object.keys(values)) el(k).value = String(values[k]); },
    call(name) { ctx.handlers[name](); },
    /** Result panel text with tags stripped, e.g. "Speed12.00 knDistance30.00 nm..." */
    text(id) { return els[id].innerHTML.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(); },
    isError(id) { return /\berr\b/.test(els[id].className); }
  };
}

module.exports = { HTML_PATH, html, script, loadCore, loadUI };
