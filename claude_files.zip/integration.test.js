"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { html, loadUI } = require("./helpers");

// Integration = real UI handlers + real calculation code + real formatting,
// driven through a minimal fake DOM (ids in, result-panel markup out).

test("file is self-contained: no external URLs, scripts or stylesheets", () => {
  assert.equal(/https?:\/\//i.test(html), false);
  assert.equal(/<script[^>]+src=/i.test(html), false);
  assert.equal(/<link[^>]+href=/i.test(html), false);
  assert.match(html, /<!DOCTYPE html>/);
  assert.match(html, /<\/html>\s*$/);
});

test("every tab button points at an existing section, every handler at an existing button", () => {
  const tabs = [...html.matchAll(/data-tab="([^"]+)"/g)].map(m => m[1]);
  assert.equal(tabs.length, 6);
  for (const t of tabs) assert.match(html, new RegExp(`<section class="tab[^"]*" id="${t}"`));
  const ui = loadUI();
  const doNames = [...html.matchAll(/data-do="([^"]+)"/g)].map(m => m[1]);
  assert.equal(doNames.length, 7);
  for (const n of doNames) assert.equal(typeof ui.ctx.handlers[n], "function", n);
});

test("every input id read by the script exists in the markup", () => {
  const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]));
  const script = html.split("<script>")[1];
  const used = [...script.matchAll(/(?:req|opt|optZero|val)\("([a-z_0-9]+)"/g)].map(m => m[1]);
  const resultIds = [...script.matchAll(/run\("([a-z_]+)"/g)].map(m => m[1]);
  const missing = [...used, ...resultIds].filter(id => !ids.has(id));
  assert.deepEqual(missing, []);
});

test("buildPos generates the six position inputs with the expected ids", () => {
  const ui = loadUI();
  ui.ctx.buildPos("p_cd1", "cd1");
  const out = ui.els.p_cd1.innerHTML;
  for (const s of ["cd1_latd", "cd1_latm", "cd1_lath", "cd1_lond", "cd1_lonm", "cd1_lonh"]) assert.ok(out.includes(`id="${s}"`), s);
});

test("Speed / Distance / Time panel", () => {
  const ui = loadUI();
  ui.set({ dst_s: 12, dst_d: 30 });
  ui.call("calcDST");
  assert.equal(ui.isError("r_dst"), false);
  assert.match(ui.text("r_dst"), /Time 2 h 30 min \(2\.500 h\)/);
  ui.set({ dst_s: 10, dst_d: "", dst_h: 1, dst_m: 30 });
  ui.call("calcDST");
  assert.match(ui.text("r_dst"), /Distance 15\.00 nm/);
  ui.set({ dst_s: 10, dst_d: 20, dst_h: 2, dst_m: 0 });
  ui.call("calcDST");
  assert.equal(ui.isError("r_dst"), true);
  assert.match(ui.text("r_dst"), /exactly two/);
});

test("Course & Distance panel: London-ish parallel run and error handling", () => {
  const ui = loadUI();
  ui.set({ cd1_latd: 50, cd1_lond: 0, cd2_latd: 50, cd2_lond: 1, cd_s: 10 });
  ui.call("calcCD");
  const t = ui.text("r_cd");
  assert.equal(ui.isError("r_cd"), false);
  assert.match(t, /Mercator course 090\.0°/);
  assert.match(t, /Mercator distance 38\.6 nm/);
  assert.match(t, /D\. long 60\.0′ E/);
  assert.match(t, /Steaming time \(rhumb line\) 3 h 51 min/);
  // southern / western hemispheres via the select values
  ui.set({ cd1_latd: 10, cd1_lath: -1, cd1_lond: 20, cd1_lonh: -1, cd2_latd: 11, cd2_lath: -1, cd2_lond: 20, cd2_lonh: -1 });
  ui.call("calcCD");
  assert.match(ui.text("r_cd"), /D\. lat 60\.0′ S/);
  assert.match(ui.text("r_cd"), /Mercator course 180\.0°/);
  // missing destination
  ui.set({ cd2_latd: "" });
  ui.call("calcCD");
  assert.equal(ui.isError("r_cd"), true);
  assert.match(ui.text("r_cd"), /Destination latitude degrees is required/);
  // out of range
  ui.set({ cd2_latd: 95 });
  ui.call("calcCD");
  assert.match(ui.text("r_cd"), /must be between 0 and 90/);
});

test("Course & Distance panel: identical positions", () => {
  const ui = loadUI();
  ui.set({ cd1_latd: 10, cd1_lond: 10, cd2_latd: 10, cd2_lond: 10 });
  ui.call("calcCD");
  assert.match(ui.text("r_cd"), /Both positions are identical/);
});

test("DR panel formats position as deg + decimal minutes with hemisphere", () => {
  const ui = loadUI();
  ui.set({ dr_latd: 0, dr_lond: 0, dr_c: 0, dr_d: 90 });
  ui.call("calcDR");
  const t = ui.text("r_dr");
  assert.match(t, /Latitude in 01° 30\.0′ N/);
  assert.match(t, /Longitude in 000° 00\.0′ E/);
  ui.set({ dr_latd: 60, dr_lond: 0, dr_c: 90, dr_d: 60 });
  ui.call("calcDR");
  assert.match(ui.text("r_dr"), /Longitude in 002° 00\.0′ E/);
  ui.set({ dr_latd: 88, dr_lond: 0, dr_c: 0, dr_d: 200 });
  ui.call("calcDR");
  assert.equal(ui.isError("r_dr"), true);
});

test("Compass panel: T -> M/C and compass error label", () => {
  const ui = loadUI();
  ui.set({ cm_dir: 90, cm_type: "T", cm_var: 5, cm_varh: "W", cm_dev: 2, cm_devh: "E" });
  ui.call("calcCMP");
  const t = ui.text("r_cmp");
  assert.match(t, /True 090\.0°/); assert.match(t, /Magnetic 095\.0°/); assert.match(t, /Compass 093\.0°/);
  assert.match(t, /Compass error 3\.0° W/);
  ui.set({ cm_var: "", cm_dev: "" });                 // blank correction fields count as zero
  ui.call("calcCMP");
  assert.match(ui.text("r_cmp"), /Compass 090\.0°/);
});

test("Set & drift panels", () => {
  const ui = loadUI();
  ui.set({ st_track: 0, st_speed: 10, st_set: 90, st_rate: 5, st_dist: 26 });
  ui.call("calcSteer");
  const t = ui.text("r_st");
  assert.match(t, /Course to steer 330\.0°/);
  assert.match(t, /30\.0° to port of track/);
  assert.match(t, /Speed over ground 8\.66 kn/);
  assert.match(t, /Time for distance 3 h 00 min/);
  ui.set({ st_speed: 3 });
  ui.call("calcSteer");
  assert.equal(ui.isError("r_st"), true);
  assert.match(ui.text("r_st"), /too strong/);
  ui.set({ rs_course: 0, rs_speed: 10, rs_set: 90, rs_rate: 10 });
  ui.call("calcResultant");
  assert.match(ui.text("r_rs"), /Track made good 045\.0°/);
  assert.match(ui.text("r_rs"), /Speed over ground 14\.14 kn/);
});

test("CPA panel: closing and opening situations", () => {
  const ui = loadUI();
  ui.set({ cp_oc: 0, cp_os: 10, cp_b: 90, cp_r: 5, cp_tc: 270, cp_ts: 10 });
  ui.call("calcCPA");
  let t = ui.text("r_cpa");
  assert.match(t, /CPA 3\.54 nm/); assert.match(t, /Time to CPA 0 h 15 min/);
  ui.set({ cp_b: 180, cp_r: 3, cp_tc: 0, cp_ts: 5 });
  ui.call("calcCPA");
  t = ui.text("r_cpa");
  assert.match(t, /Opening/);
  ui.set({ cp_b: 90, cp_r: 5, cp_tc: 0, cp_ts: 10 });
  ui.call("calcCPA");
  assert.match(ui.text("r_cpa"), /Relative motion None/);
});

test("Invalid numeric text is reported, never silently computed", () => {
  const ui = loadUI();
  ui.set({ st_track: "abc", st_speed: 10, st_set: 0, st_rate: 0 });
  ui.call("calcSteer");
  assert.equal(ui.isError("r_st"), true);
  assert.match(ui.text("r_st"), /Desired track is required/);
});
