"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { loadCore } = require("./helpers");

const C = loadCore();
const near = (got, want, tol = 1e-6, msg = "") =>
  assert.ok(Math.abs(got - want) <= tol, `${msg} expected ${want}, got ${got} (tol ${tol})`);
const angDiff = (a, b) => Math.abs(((a - b + 540) % 360 + 360) % 360 - 180);

// Small deterministic PRNG (mulberry32) so "random" tests are reproducible.
function rng(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

test("angle normalisation", () => {
  near(C.nb(-10), 350); near(C.nb(370), 10); near(C.nb(360), 0);
  near(C.nd(190), -170); near(C.nd(-190), 170); near(C.nd(180), -180); near(C.nd(0), 0);
});

test("meridional parts (spherical)", () => {
  near(C.mp(0), 0, 1e-9);
  near(C.mp(45), 3030.0, 0.1);
  near(C.mp(-30), -C.mp(30), 1e-9);
});

test("solveDST: solves each unknown", () => {
  const a = C.solveDST(12, 30, NaN); near(a.t, 2.5);
  const b = C.solveDST(NaN, 30, 2); near(b.s, 15);
  const c = C.solveDST(10, NaN, 1.5); near(c.d, 15);
});

test("solveDST: rejects bad input", () => {
  assert.throws(() => C.solveDST(10, 20, 2), /exactly two/);
  assert.throws(() => C.solveDST(NaN, NaN, 2), /exactly two/);
  assert.throws(() => C.solveDST(0, 20, NaN), /Speed must be above zero/);
  assert.throws(() => C.solveDST(NaN, 20, 0), /Time must be above zero/);
});

test("courseDist: cardinal directions and distances", () => {
  let r = C.courseDist({ lat: 0, lon: 0 }, { lat: 1, lon: 0 });
  near(r.merC, 0); near(r.merD, 60, 1e-6);
  r = C.courseDist({ lat: 1, lon: 0 }, { lat: 0, lon: 0 });
  near(r.merC, 180); near(r.merD, 60, 1e-6);
  r = C.courseDist({ lat: 50, lon: 0 }, { lat: 50, lon: 1 });
  near(r.merC, 90); near(r.merD, 60 * Math.cos(50 * Math.PI / 180), 1e-6);
  r = C.courseDist({ lat: 50, lon: 1 }, { lat: 50, lon: 0 });
  near(r.merC, 270);
});

test("courseDist: quadrants", () => {
  const r = C.courseDist({ lat: 10, lon: 10 }, { lat: 9, lon: 9 });
  assert.ok(r.merC > 180 && r.merC < 270, "SW quadrant: " + r.merC);
  const s = C.courseDist({ lat: 10, lon: 10 }, { lat: 9, lon: 11 });
  assert.ok(s.merC > 90 && s.merC < 180, "SE quadrant: " + s.merC);
});

test("courseDist: crosses the 180° meridian the short way", () => {
  const r = C.courseDist({ lat: 10, lon: 170 }, { lat: 10, lon: -170 });
  near(r.dlon, 1200, 1e-6); near(r.merC, 90);
  const w = C.courseDist({ lat: 10, lon: -170 }, { lat: 10, lon: 170 });
  near(w.dlon, -1200, 1e-6); near(w.merC, 270);
});

test("courseDist: great circle on the equator, plane vs Mercator agree on short legs", () => {
  const g = C.courseDist({ lat: 0, lon: 0 }, { lat: 0, lon: 90 });
  near(g.gcD, 5400, 0.01); near(g.gcC, 90, 1e-6);
  const s = C.courseDist({ lat: 45, lon: 0 }, { lat: 45.2, lon: 0.3 });
  near(s.merD, s.plD, 0.05); near(s.merC, s.plC, 0.2);
});

test("courseDist: great circle is never longer than the rhumb line", () => {
  const r = C.courseDist({ lat: 50, lon: -5 }, { lat: 40, lon: -70 });
  assert.ok(r.gcD < r.merD, `gc ${r.gcD} < rhumb ${r.merD}`);
});

test("courseDist: identical points and polar latitudes", () => {
  assert.equal(C.courseDist({ lat: 5, lon: 5 }, { lat: 5, lon: 5 }).same, true);
  assert.throws(() => C.courseDist({ lat: 89.5, lon: 0 }, { lat: 10, lon: 0 }), /within 89/);
});

test("drPos: simple moves and longitude wrap", () => {
  near(C.drPos({ lat: 0, lon: 0 }, 0, 60).lat, 1);
  near(C.drPos({ lat: 60, lon: 0 }, 90, 60).lon, 2);         // parallel sailing: dlong = dist / cos(lat)
  near(C.drPos({ lat: 0, lon: 179.5 }, 90, 60).lon, -179.5); // wraps across 180°
  near(C.drPos({ lat: 0, lon: 0 }, 180, 120).lat, -2);
});

test("drPos: refuses to leave the Mercator domain", () => {
  assert.throws(() => C.drPos({ lat: 88, lon: 0 }, 0, 200), /beyond 89/);
  assert.throws(() => C.drPos({ lat: 89.5, lon: 0 }, 0, 1), /within 89/);
});

test("drPos <-> courseDist round trip (200 seeded random cases)", () => {
  const r = rng(12345);
  for (let i = 0; i < 200; i++) {
    const p = { lat: (r() - 0.5) * 120, lon: (r() - 0.5) * 358 };
    const course = r() * 360, dist = 10 + r() * 490;
    const q = C.drPos(p, course, dist);
    const back = C.courseDist(p, { lat: q.lat, lon: q.lon });
    near(back.merD, dist, 1e-4 * dist / 100 + 1e-6, `dist case ${i}`);
    assert.ok(angDiff(back.merC, course) < 1e-3, `course case ${i}: ${back.merC} vs ${course}`);
  }
});

test("compassConv: worked example and E/W conventions", () => {
  let c = C.compassConv(90, "T", -5, 2);        // 5°W variation, 2°E deviation
  near(c.m, 95); near(c.c, 93); near(c.t, 90);
  c = C.compassConv(93, "C", -5, 2); near(c.m, 95); near(c.t, 90);
  c = C.compassConv(95, "M", -5, 2); near(c.t, 90); near(c.c, 93);
  c = C.compassConv(2, "T", 5, 0);              // wraps below 0
  near(c.m, 357);
});

test("compassConv: T -> M -> C -> T round trip for every input type", () => {
  const r = rng(99);
  for (let i = 0; i < 100; i++) {
    const t = r() * 360, vr = (r() - 0.5) * 60, dv = (r() - 0.5) * 20;
    const f = C.compassConv(t, "T", vr, dv);
    assert.ok(angDiff(C.compassConv(f.c, "C", vr, dv).t, t) < 1e-9);
    assert.ok(angDiff(C.compassConv(f.m, "M", vr, dv).t, t) < 1e-9);
  }
});

test("steer: no current, beam current, head/following current", () => {
  let s = C.steer(45, 12, 0, 0); near(s.heading, 45); near(s.sog, 12); near(s.wca, 0);
  s = C.steer(0, 10, 90, 5);   near(s.heading, 330, 1e-6); near(s.sog, Math.sqrt(75), 1e-9); near(s.wca, -30, 1e-6);
  s = C.steer(0, 10, 180, 2);  near(s.heading, 0, 1e-6);   near(s.sog, 8, 1e-9);   // head current
  s = C.steer(0, 10, 0, 2);    near(s.sog, 12, 1e-9);                             // following current
});

test("steer: impossible cases raise clear errors", () => {
  assert.throws(() => C.steer(0, 4, 90, 5), /too strong/);
  assert.throws(() => C.steer(0, 5, 180, 5), /cannot make headway/);
  assert.throws(() => C.steer(0, 0, 90, 1), /Ship speed/);
});

test("steer is the inverse of resultant (150 seeded random cases)", () => {
  const r = rng(2024);
  for (let i = 0; i < 150; i++) {
    const V = 5 + r() * 20, rate = r() * V * 0.7, set = r() * 360, track = r() * 360;
    let s;
    try { s = C.steer(track, V, set, rate); } catch (e) { continue; } // skip head-on cases that cannot make headway
    const back = C.resultant(s.heading, V, set, rate);
    assert.ok(angDiff(back.track, track) < 1e-6, `track ${back.track} vs ${track}`);
    near(back.sog, s.sog, 1e-9);
  }
});

test("resultant: vector addition and zero case", () => {
  const q = C.resultant(0, 10, 90, 10); near(q.track, 45); near(q.sog, Math.sqrt(200), 1e-9);
  const z = C.resultant(0, 5, 180, 5);  assert.ok(Number.isNaN(z.track)); near(z.sog, 0, 1e-9);
});

test("cpaCalc: head-on, crossing, parallel, diverging, no relative motion", () => {
  let k = C.cpaCalc(0, 10, 0, 5, 180, 10);          // head-on
  near(k.cpa, 0, 1e-9); near(k.t, 0.25); assert.equal(k.closing, true);
  k = C.cpaCalc(0, 10, 90, 5, 270, 10);              // crossing
  near(k.cpa, 3.5355, 1e-3); near(k.t, 0.25); near(k.rc, 225, 1e-6);
  k = C.cpaCalc(0, 10, 90, 5, 0, 10);                // parallel, same speed
  assert.equal(k.still, true); near(k.cpa, 5);
  k = C.cpaCalc(0, 10, 180, 3, 0, 5);                // target astern, slower: opening
  assert.equal(k.closing, false); assert.ok(k.t < 0); near(k.cpa, 3);
  k = C.cpaCalc(0, 10, 90, 5, 300, 10);              // converging at an angle
  assert.equal(k.closing, true);
});

test("built-in selfTest() reports only PASS lines", () => {
  const out = C.selfTest();
  assert.ok(out.length >= 20);
  assert.equal(out.filter(l => !l.startsWith("PASS")).length, 0);
});
