Here’s a **comprehensive README** for your Chartwork Calculator project. I’ve structured it like professional open-source documentation, with setup, architecture, logic explanations, endpoints, tests, and environment details.

---

# 📘 Chartwork Calculator Web App

A lightweight **web-based Chartwork Calculator** built with **HTML, CSS, and JavaScript**.  
It helps navigators and students of **Nautical Science** perform essential calculations: distance traveled, adjusted course, and position shift under wind/current drift.

---

## 🚀 Quick Start

1. Clone or download the repository.
2. Open `index.html` in any modern browser (Chrome, Edge, Firefox).
3. Input ship speed, course, time, and drift values.
4. Click **Calculate** to view results.

No external dependencies — runs entirely client-side.

---

## 🏗️ Project Architecture Overview

```
chartwork-calculator/
│
├── index.html        # Main entry point, contains structure and script
├── style.css         # (Optional) Extracted CSS if modularized
├── script.js         # (Optional) Extracted JS if modularized
└── README.md         # Documentation
```

- **HTML**: Provides form inputs and results container.
- **CSS**: Styles the calculator UI (responsive, clean).
- **JavaScript**: Implements calculation logic (vector math).

---

## ⚙️ Setup Instructions

- No installation required.
- Works offline.
- Just open `index.html` in a browser.

Optional:  
To modularize, move CSS into `style.css` and JS into `script.js`, then link them in `index.html`.

---

## 🧮 Complex Logic & Design Decisions

- **Vector-based calculation**:  
  Ship movement and drift are treated as vectors.  
  - Ship vector: \( x = d \cdot \cos(\theta), y = d \cdot \sin(\theta) \)  
  - Drift vector: \( x = v \cdot t \cdot \cos(\phi), y = v \cdot t \cdot \sin(\phi) \)  
  - Resultant vector = sum of ship + drift vectors.

- **Adjusted course**:  
  Derived from `atan2(yTotal, xTotal)` to ensure correct quadrant.

- **Error handling**:  
  Defaults to `0` if inputs are missing.

- **Design choice**:  
  Kept UI minimal and intuitive — no external libraries, ensuring portability.

---

## 📡 Endpoints, Inputs & Outputs

This is a **client-side app** (no backend). Inputs/outputs are handled via DOM.

### Inputs
- `speed` (knots, float)
- `course` (degrees, float)
- `time` (hours, float)
- `windDrift` (knots, float)
- `driftDir` (degrees, float)

### Outputs
- **Distance (no drift)**: nautical miles
- **Adjusted Distance**: nautical miles
- **Adjusted Course**: degrees
- **Position Shift (X,Y)**: vector displacement in nm

---

## 🧪 Tests & Example Usage

### Unit Tests (pseudo-code)
```javascript
// Example: ship speed 10 knots, course 90°, time 2h, no drift
assertEqual(calcDistance(10, 2), 20);
assertEqual(calcCourse(90, 0, 0), 90);

// Example: drift 2 knots @ 180°, 1h
assertEqual(calcDrift(2, 1, 180), {x: -2, y: 0});
```

### Integration Test
1. Input: Speed = 12, Course = 90°, Time = 5h, Drift = 2 knots @ 120°.
2. Expected:
   - Distance (no drift): 60 nm
   - Adjusted Distance ≈ 69.28 nm
   - Adjusted Course ≈ 97.13°
   - Position Shift ≈ (x=60+(-1), y=0+8.66)

### Example Usage
Open browser console and run:
```javascript
calculate(); // after filling inputs
```

---

## 🌍 Environment & Dependencies

- **Environment**: Any modern browser (Chrome, Edge, Firefox, Safari).
- **Dependencies**: None (pure HTML/CSS/JS).
- **Optional Enhancements**:
  - Add Chart.js for plotting vectors.
  - Use Bootstrap for responsive design.

---

## 📖 Future Enhancements

- Visual plotting of ship path and drift vectors.
- Route optimization.
- Integration with GPS data.

---

This README should give you a **professional-grade documentation** for your project. Would you like me to also generate a **test harness file** (e.g., `tests.js`) with runnable unit tests so you can verify calculations directly in the browser console?
