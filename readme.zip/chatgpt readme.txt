Below is a comprehensive README for the **Chartwork Calculator** web app above. It is written for a small, dependency-free browser application and documents the actual calculations implemented in the code.

# ⚓ Chartwork Calculator

A lightweight, browser-based **Chartwork Calculator** for studying basic marine navigation and nautical science.

The application performs common navigation calculations involving:

* Speed, distance and time
* Initial true course and great-circle distance
* Estimated Time of Arrival (ETA)
* Current set and drift
* Resultant course and speed

The application is implemented as a **single self-contained HTML file** containing HTML, CSS and JavaScript.

---

## 1. Project Overview

### Purpose

A Chartwork Calculator helps a navigator perform mathematical calculations used during marine navigation.

Traditional chartwork may involve:

* Nautical charts
* Dividers
* Parallel rulers
* Compass
* Nautical almanacs
* Calculator

This application provides a small digital tool for practicing the mathematical portion of chartwork.

### Main goals

1. Keep the application simple.
2. Require no server.
3. Require no database.
4. Require no external JavaScript libraries.
5. Work directly in a modern web browser.
6. Provide immediate calculation results.
7. Provide validation for invalid inputs.
8. Keep the application suitable for educational experiments in Data Science and Nautical Science.

---

# 2. Features

## 2.1 Speed, Distance & Time

The calculator supports three modes:

### Find Time

Formula:

```text
Time = Distance / Speed
```

Example:

```text
Distance = 120 NM
Speed = 12 knots

Time = 120 / 12
     = 10 hours
```

### Find Distance

Formula:

```text
Distance = Speed × Time
```

Example:

```text
Speed = 15 knots
Time = 4 hours

Distance = 15 × 4
          = 60 NM
```

### Find Speed

Formula:

```text
Speed = Distance / Time
```

Example:

```text
Distance = 90 NM
Time = 6 hours

Speed = 90 / 6
      = 15 knots
```

---

# 3. Course and Distance Calculation

The second calculator accepts:

```text
Start Latitude
Start Longitude
End Latitude
End Longitude
```

It calculates:

1. Initial true course
2. Great-circle distance

The calculation treats Earth as a sphere.

The application uses an approximate Earth radius equivalent to:

```text
3440.065 nautical miles
```

This is suitable for basic educational calculations.

It should not be considered a replacement for approved navigation methods or navigation equipment.

---

# 4. ETA Calculation

The ETA calculator accepts:

```text
Departure Date
Departure Time
Distance
Speed
```

The basic calculation is:

```text
Travel Time = Distance / Speed
```

Then:

```text
ETA = Departure Time + Travel Time
```

Example:

```text
Departure: 2026-09-21 08:00
Distance: 120 NM
Speed: 12 knots

Travel time = 120 / 12
            = 10 hours

ETA = 18:00
```

The browser's JavaScript `Date` object is used to add the calculated travel duration.

---

# 5. Current Set and Drift

The application models the vessel's movement through water and adds the current vector.

Inputs:

```text
Ship Course
Ship Speed
Current Set
Current Drift
```

The calculation converts both vectors into north/east components.

For a course `C` and speed `S`:

```text
East  = S × sin(C)
North = S × cos(C)
```

For current set `D` and drift `V`:

```text
Current East  = V × sin(D)
Current North = V × cos(D)
```

The vectors are added:

```text
Resultant East  = Ship East + Current East
Resultant North = Ship North + Current North
```

Resultant speed:

```text
Resultant Speed =
sqrt(East² + North²)
```

Resultant course:

```text
Course = atan2(East, North)
```

The result is normalized to:

```text
0° to <360°
```

---

# 6. Project Structure

The application is intentionally small.

```text
chartwork-calculator/
│
├── chartwork-calculator.html
│
└── README.md
```

There are no required external dependencies.

The HTML file contains:

```text
HTML
 ├── Page structure
 ├── Input controls
 ├── Buttons
 └── Result containers

CSS
 ├── Layout
 ├── Cards
 ├── Forms
 ├── Buttons
 └── Responsive design

JavaScript
 ├── Input parsing
 ├── Validation
 ├── SDT calculation
 ├── Course calculation
 ├── ETA calculation
 └── Current calculation
```

---

# 7. Architecture

The application uses a simple client-side architecture.

```text
             Browser
                │
                ▼
        ┌─────────────────┐
        │   HTML UI       │
        └────────┬────────┘
                 │
                 ▼
        ┌─────────────────┐
        │ JavaScript      │
        │ Calculation     │
        │ Functions       │
        └────────┬────────┘
                 │
       ┌─────────┼──────────┐
       ▼         ▼          ▼
     SDT      Course       ETA
                         Current
                 │
                 ▼
        ┌─────────────────┐
        │ Result Display  │
        └─────────────────┘
```

There is no backend API.

There is no database.

There is no network request.

All calculations happen locally inside the browser.

---

# 8. Quick Start

## Step 1: Create the project

Create a directory:

```text
chartwork-calculator
```

Create:

```text
chartwork-calculator.html
```

Paste the complete application code into that file.

---

## Step 2: Open the application

Double-click:

```text
chartwork-calculator.html
```

The application should open in a modern browser.

Supported browsers include current versions of:

* Chrome
* Microsoft Edge
* Firefox
* Safari

---

## Step 3: Perform a calculation

For example, under **Speed, Distance & Time**:

```text
Calculation: Find Time
Speed:       12
Distance:    120
```

Click:

```text
Calculate
```

Expected result:

```text
Time = 10.00 hours
```

---

# 9. Environment

## Minimum environment

The application only requires:

```text
Modern web browser
```

Recommended:

```text
Google Chrome
Microsoft Edge
Mozilla Firefox
Safari
```

No Node.js installation is required.

No Python installation is required.

No Java installation is required.

No web server is required.

---

# 10. Dependencies

## Runtime dependencies

None.

The application uses:

```text
HTML5
CSS3
JavaScript
```

No external packages are imported.

There are no CDN dependencies.

There are no npm dependencies.

There are no third-party APIs.

---

# 11. JavaScript Compatibility

The application uses standard modern JavaScript features including:

```javascript
const
let
template literals
Math.hypot()
Number.isFinite()
arrow functions
```

A modern browser is therefore recommended.

---

# 12. Input Data Contracts

Because this is a browser-only application, there are no HTTP API endpoints.

Instead, each calculator function has an implicit input/output contract.

---

## 12.1 Speed-Distance-Time Contract

### Function

```javascript
calcSDT()
```

### Inputs

DOM elements:

```text
sdtType
sdtSpeed
sdtDistance
sdtTime
```

### `sdtType`

Allowed values:

```text
time
distance
speed
```

### Example

```text
type = time
speed = 12
distance = 120
```

### Output

Displayed in:

```text
sdtResult
```

Expected:

```text
Time = 10.00 hours
```

---

# 13. Course Calculation Contract

### Function

```javascript
calcCourse()
```

### Inputs

```text
lat1
lon1
lat2
lon2
```

### Constraints

Latitude:

```text
-90 <= latitude <= 90
```

Longitude:

```text
-180 <= longitude <= 180
```

### Example

```text
lat1 = 18.5204
lon1 = 73.8567

lat2 = 19.0760
lon2 = 72.8777
```

### Output

Displayed in:

```text
courseResult
```

Example format:

```text
Initial True Course = XX.XX°T
Great-circle Distance = XX.XX NM
```

---

# 14. ETA Contract

### Function

```javascript
calcETA()
```

### Inputs

```text
etaDate
etaTime
etaDistance
etaSpeed
```

### Requirements

```text
Date must be supplied.
Time must be supplied.
Distance must be >= 0.
Speed must be > 0.
```

### Example

```text
Date     = 2026-09-21
Time     = 08:00
Distance = 120
Speed    = 12
```

### Output

```text
Passage Time = 10.00 hours
ETA = ...
```

---

# 15. Current Set & Drift Contract

### Function

```javascript
calcCurrent()
```

### Inputs

```text
shipCourse
shipSpeed
currentSet
currentDrift
```

### Constraints

Course:

```text
0 <= course <= 360
```

Speed:

```text
speed >= 0
```

Current drift:

```text
drift >= 0
```

### Output

```text
Resultant Course = XX.XX°T
Resultant Speed = XX.XX knots
```

---

# 16. Helper Functions

The application has several reusable helper functions.

## `$()`

```javascript
const $ = id => document.getElementById(id);
```

Purpose:

Provides short access to DOM elements.

Instead of:

```javascript
document.getElementById("sdtSpeed")
```

the application can use:

```javascript
$("sdtSpeed")
```

---

## `num()`

```javascript
function num(id){
  const v=parseFloat($(id).value);
  return Number.isFinite(v) ? v : NaN;
}
```

Purpose:

Reads a numeric input and converts it to a JavaScript number.

Invalid values become:

```text
NaN
```

This makes validation easier.

---

## `valid()`

```javascript
function valid(v){
  return Number.isFinite(v);
}
```

Purpose:

Checks whether a value is a valid finite number.

---

## `fmt()`

```javascript
function fmt(v,d=2){
  return Number(v).toFixed(d);
}
```

Purpose:

Formats calculation results.

Example:

```javascript
fmt(12.3456)
```

produces:

```text
12.35
```

---

## `norm360()`

```javascript
function norm360(v){
  return ((v % 360) + 360) % 360;
}
```

Purpose:

Normalizes angles.

Examples:

```text
370° → 10°
-10° → 350°
720° → 0°
```

This is particularly useful for navigation courses.

---

# 17. Complex Logic Explained

## 17.1 Why use radians?

JavaScript trigonometric functions use radians.

Therefore:

```javascript
const r = Math.PI / 180;
```

converts degrees to radians.

For example:

```text
90° × π/180 = π/2 radians
```

Navigation users normally work in degrees, so conversion is necessary before calling:

```javascript
Math.sin()
Math.cos()
Math.atan2()
```

---

# 18. Great-Circle Calculation

The application uses the spherical-distance formula commonly expressed through the haversine calculation.

The angular distance is calculated from:

```text
Δlatitude
Δlongitude
```

The central angle is:

```text
2 × atan2(
    sqrt(a),
    sqrt(1-a)
)
```

The nautical distance is then approximately:

```text
distance = Earth radius × central angle
```

where:

```text
Earth radius = 3440.065 NM
```

This approach avoids assuming that latitude and longitude differences can simply be treated as flat Cartesian coordinates.

---

# 19. Initial Bearing Calculation

The initial bearing uses:

```text
y = sin(Δlongitude) × cos(latitude2)

x =
cos(latitude1) × sin(latitude2)
-
sin(latitude1) × cos(latitude2) × cos(Δlongitude)
```

The bearing is then obtained using:

```javascript
Math.atan2(y,x)
```

and converted back to degrees.

Finally:

```javascript
norm360()
```

ensures the result lies within the normal compass range.

---

# 20. Vector Calculation for Current

The current calculation is one of the more important pieces of logic.

A vessel's velocity can be represented as two components:

```text
North component
East component
```

For a course measured clockwise from north:

```text
East  = Speed × sin(Course)
North = Speed × cos(Course)
```

The same process is applied to the current.

Then:

```text
Vessel vector
       +
Current vector
       =
Resultant vector
```

This allows the application to determine the resulting movement over the ground.

---

# 21. Design Decisions

## Single HTML file

The project deliberately uses one file.

Advantages:

* Easy to copy
* Easy to run
* Easy to distribute
* No build process
* No package installation
* Good for experiments
* Easy to submit as a small academic project

---

## No framework

The application does not use:

```text
React
Vue
Angular
jQuery
Bootstrap
```

This reduces complexity.

For a small calculator, native JavaScript is sufficient.

---

## Client-side calculation

All calculations are performed in the browser.

Advantages:

```text
Fast
Private
Offline-capable
No server cost
No API dependency
```

---

## Input validation

The application validates numeric values before performing calculations.

For example:

```javascript
if(!(s>0) || !(d>=0))
```

prevents invalid time calculations involving zero or negative speed.

---

# 22. Error Handling

Errors are displayed inside the relevant result area.

Example:

```text
Enter a positive speed and a valid distance.
```

The application avoids throwing errors for ordinary invalid user input.

Instead, it displays a readable validation message.

---

# 23. Practical Usage Examples

## Example 1 — Passage Time

Input:

```text
Speed = 15 knots
Distance = 90 NM
```

Calculation:

```text
Time = 90 / 15
     = 6 hours
```

Expected output:

```text
Time = 6.00 hours
```

---

## Example 2 — Distance

Input:

```text
Speed = 10 knots
Time = 5 hours
```

Calculation:

```text
Distance = 10 × 5
         = 50 NM
```

Expected:

```text
Distance = 50.00 NM
```

---

## Example 3 — Speed

Input:

```text
Distance = 150 NM
Time = 10 hours
```

Calculation:

```text
Speed = 150 / 10
      = 15 knots
```

Expected:

```text
Speed = 15.00 knots
```

---

## Example 4 — Current

Suppose:

```text
Ship course = 090°T
Ship speed = 10 kn

Current set = 000°T
Current drift = 2 kn
```

The ship moves east while the current moves north.

Therefore:

```text
Ship vector:
East = 10
North = 0

Current:
East = 0
North = 2
```

Resultant:

```text
East = 10
North = 2
```

Resultant speed:

```text
sqrt(10² + 2²)
≈ 10.20 knots
```

Resultant course is approximately:

```text
078.69°T
```

---

# 24. Testing Strategy

Testing can be performed at three levels:

```text
1. Unit testing
2. Integration testing
3. Browser/manual testing
```

The current application does not include a test framework because it has no dependencies.

The following tests can nevertheless be used to verify the calculation logic.

---

# 25. Unit Test Examples

The calculation functions interact directly with the DOM, so the simplest testing approach is to load the application in a browser and set the input values programmatically.

Example:

```javascript
document.getElementById("sdtType").value = "time";
document.getElementById("sdtSpeed").value = "12";
document.getElementById("sdtDistance").value = "120";

calcSDT();

console.assert(
  document.getElementById("sdtResult").textContent.includes("10.00"),
  "SDT time calculation failed"
);
```

Expected:

```text
PASS
```

---

# 26. SDT Test Cases

### Test 1

```text
Speed = 12
Distance = 120
```

Expected:

```text
10 hours
```

### Test 2

```text
Speed = 15
Time = 4
```

Expected:

```text
60 NM
```

### Test 3

```text
Distance = 90
Time = 6
```

Expected:

```text
15 knots
```

### Test 4 — invalid speed

```text
Speed = 0
Distance = 100
Find Time
```

Expected:

```text
Validation error
```

---

# 27. Current Calculation Test

Example:

```javascript
document.getElementById("shipCourse").value = "090";
document.getElementById("shipSpeed").value = "10";
document.getElementById("currentSet").value = "000";
document.getElementById("currentDrift").value = "2";

calcCurrent();

const result =
  document.getElementById("currentResult").textContent;

console.assert(
  result.includes("10.20"),
  "Current resultant speed failed"
);
```

The expected resultant speed is approximately:

```text
10.20 knots
```

---

# 28. Integration Testing

An integration test verifies that:

```text
HTML input
     ↓
JavaScript calculation
     ↓
DOM result
```

works as a complete workflow.

Example:

```javascript
const speed = document.getElementById("sdtSpeed");
const distance = document.getElementById("sdtDistance");
const type = document.getElementById("sdtType");

type.value = "time";
speed.value = "20";
distance.value = "100";

calcSDT();

const result =
  document.getElementById("sdtResult").textContent;

console.assert(
  result.includes("5.00"),
  "Integration test failed"
);
```

Expected:

```text
Time = 5.00 hours
```

---

# 29. Manual Browser Test Checklist

After opening the application, verify:

### UI

* [ ] Page loads.
* [ ] Four calculator sections appear.
* [ ] Buttons are clickable.
* [ ] Inputs accept numbers.
* [ ] Layout works on desktop.
* [ ] Layout works on mobile.

### SDT

* [ ] Find Time works.
* [ ] Find Distance works.
* [ ] Find Speed works.
* [ ] Invalid values produce errors.

### Course

* [ ] Valid coordinates produce a result.
* [ ] Latitude outside ±90 is rejected.
* [ ] Longitude outside ±180 is rejected.

### ETA

* [ ] Valid date/time works.
* [ ] Zero speed is rejected.
* [ ] Distance produces correct passage duration.

### Current

* [ ] Valid ship vector works.
* [ ] Valid current vector works.
* [ ] Resultant course is between 0° and 360°.

---

# 30. Console Verification

Open browser developer tools:

```text
F12
```

Then select:

```text
Console
```

The application should not produce JavaScript syntax errors during normal operation.

A useful manual check is:

```javascript
typeof calcSDT
```

Expected:

```text
"function"
```

Likewise:

```javascript
typeof calcCourse
```

Expected:

```text
"function"
```

and:

```javascript
typeof calcETA
```

Expected:

```text
"function"
```

and:

```javascript
typeof calcCurrent
```

Expected:

```text
"function"
```

---

# 31. Running a Local Web Server

A server is not required, but one can be used for development.

## Python

If Python is installed:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000/chartwork-calculator.html
```

---

## Node.js

If Node.js is available, a static HTTP server can also be used.

For example, with a suitable static-server package:

```bash
npx serve .
```

The application itself does not require Node.js.

---

# 32. No API Endpoints

This project has:

```text
0 REST endpoints
0 GraphQL endpoints
0 database endpoints
0 external API calls
```

Everything occurs locally.

Therefore there is no API authentication, API key, request body, response JSON, or HTTP error contract.

The logical interfaces are JavaScript functions.

---

# 33. Data Contract Summary

| Calculator | Inputs                           | Output                   |
| ---------- | -------------------------------- | ------------------------ |
| SDT        | Speed, distance, time, operation | Calculated value         |
| Course     | Start/end latitude & longitude   | Bearing + distance       |
| ETA        | Departure + distance + speed     | Passage time + ETA       |
| Current    | Ship course/speed + set/drift    | Resultant course + speed |

Units:

| Quantity  | Unit                |
| --------- | ------------------- |
| Distance  | Nautical miles (NM) |
| Speed     | Knots               |
| Course    | Degrees True (°T)   |
| Time      | Hours               |
| Latitude  | Degrees             |
| Longitude | Degrees             |

---

# 34. Important Navigation Limitations

This application is an **educational calculator**.

It does not account for every factor required for real-world marine navigation.

For example, it does not provide complete functionality for:

* Chart projections
* Mercator sailing
* Rhumb-line sailing
* Tidal stream calculations
* Leeway
* Magnetic variation
* Compass error
* Deviation
* Wind correction
* Waypoint management
* Collision avoidance
* Electronic Chart Display and Information System (ECDIS)
* Official chart data
* Safety depth
* Under-keel clearance

The course/distance calculation uses a spherical-Earth approximation.

For actual navigation, calculations should be checked against appropriate nautical publications, charts, approved navigation equipment and applicable procedures.

---

# 35. Security

The application does not transmit user data.

There are:

```text
No cookies
No tracking code
No external JavaScript
No server
No database
No user account
```

All entered values remain in the browser page.

---

# 36. Performance

The calculations are computationally small.

Expected complexity is effectively:

```text
O(1)
```

for each calculation.

There are no loops over large datasets and no network operations.

Therefore calculations should complete essentially immediately on normal hardware.

---

# 37. Data Science Extension Ideas

Because this project is being used as a Data Science experiment, the calculator can later be extended to collect and analyze navigation calculations.

Potential additions include:

### Historical calculation storage

Store:

```text
Date
Position
Course
Speed
Distance
Current
ETA
```

Then analyze the data.

### Statistical analysis

Calculate:

```text
Mean speed
Median speed
Maximum speed
Minimum speed
Average current
ETA error
```

### Visualization

Add charts for:

```text
Speed vs time
Distance vs time
Course vs time
Current drift vs time
ETA error
```

### CSV export

A future version could export:

```csv
date,latitude,longitude,course,speed,distance,eta
```

This would allow analysis in:

* Python
* R
* Excel
* pandas
* Power BI

---

# 38. Suggested Future Architecture

For a larger Data Science project, the application could evolve into:

```text
Frontend
   │
   ├── HTML/CSS
   ├── JavaScript
   └── Charts
          │
          ▼
       REST API
          │
          ▼
       Backend
          │
          ├── Navigation calculations
          ├── Validation
          └── Analytics
          │
          ▼
       Database
```

A future version could use:

```text
Frontend: HTML + CSS + JavaScript
Backend: Python/FastAPI
Data: PostgreSQL
Analysis: pandas
Visualization: Plotly
```

However, none of these are necessary for the current calculator.

---

# 39. Example Development Workflow

A practical workflow is:

```text
1. Open HTML file
2. Test SDT
3. Test course calculation
4. Test ETA
5. Test current
6. Open browser console
7. Check for errors
8. Test invalid inputs
9. Test boundary values
10. Record results
```

For a Data Science experiment:

```text
Generate navigation inputs
        ↓
Run calculations
        ↓
Store results
        ↓
Compare expected vs calculated
        ↓
Calculate error
        ↓
Visualize results
```

---

# 40. Boundary Test Cases

Recommended boundary tests include:

```text
Latitude = -90
Latitude = 90

Longitude = -180
Longitude = 180

Course = 0
Course = 90
Course = 180
Course = 270
Course = 360

Speed = 0
Distance = 0
Drift = 0
```

Special attention should be given to:

```text
0° / 360°
```

because these represent the same compass direction.

---

# 41. Acceptance Criteria

The application can be considered functional when:

```text
[✓] HTML loads without syntax errors
[✓] CSS renders correctly
[✓] JavaScript loads correctly
[✓] SDT calculations work
[✓] Course calculation works
[✓] ETA calculation works
[✓] Current calculation works
[✓] Invalid numeric input is rejected
[✓] No external dependencies are required
[✓] Application works without an internet connection
```

---

# 42. Example Complete Usage

A student can use the application as follows:

```text
1. Open chartwork-calculator.html.

2. Calculate passage time:
      Speed = 12 kn
      Distance = 120 NM

3. Record:
      Time = 10 hours

4. Enter departure:
      08:00

5. Calculate ETA:
      18:00

6. Enter ship course and current information.

7. Calculate resultant course and speed.

8. Compare the digital calculation against
   manually calculated results.

9. Record the results in a dataset.

10. Analyze the differences using Data Science tools.
```

---

# 43. License / Usage

No license is specified by the application itself.

For academic or experimental use, retain appropriate attribution if the project is incorporated into a larger work.

---

# 44. Final Summary

The Chartwork Calculator is deliberately designed as a small, dependency-free educational web application.

Its architecture is:

```text
Single HTML file
       │
       ├── HTML
       ├── CSS
       └── JavaScript
              │
              ├── SDT
              ├── Course/Distance
              ├── ETA
              └── Current Set/Drift
```

It can run:

```text
Offline
Without a server
Without a database
Without npm
Without external libraries
```

This makes it suitable as a starting point for a larger **Data Science + Nautical Navigation** experiment.

