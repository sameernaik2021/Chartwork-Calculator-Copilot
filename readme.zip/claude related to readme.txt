I've put together a full project folder with the README, the app, and a test suite. All 33 tests pass on Node 22.

```
chartwork-calculator/
├── README.md                   comprehensive documentation
├── chartwork-calculator.html   the app (unchanged)
├── package.json                npm scripts only, no dependencies
└── tests/
    ├── helpers.js
    ├── unit.test.js            21 tests
    └── integration.test.js     12 tests
```

**What the README covers**
- **Setup:** quick start, a 60-second smoke test, and how to run the tests.
- **Architecture:** a diagram and data flow for the pure calculation layer versus the UI layer.
- **Data contracts:** every function's inputs, units and return shape, plus every element id the UI reads and writes. There are no HTTP endpoints, since the app runs entirely in the browser, so the README documents the functions and handlers instead.
- **The maths:** meridional parts, Mercator, plane and great-circle sailing, dead reckoning, the vector current triangle, and CPA, each explained.
- **Design decisions, validation rules, and every error message** with its cause.
- **Runnable Node snippets**, including a small batch experiment that writes CSV for pandas.
- **Environment and dependencies, limitations, extension steps, troubleshooting, and a CI example.**

**About the tests**
- The unit tests cover every calculation function. They include seeded random round-trip checks: dead reckoning back to course and distance, and steering back to track and speed over ground.
- The integration tests run the real page script against a small fake DOM, so no dependencies are needed. They check the id wiring, all seven calculate handlers, hemisphere selection, and error panels.
- They also check that the file has no external URLs, so it works offline.
- The first run found two mistakes in my own tests, not in the app, and I fixed them.
- To run everything, use `node --test` from the project folder. Node 22 treats `node --test tests/` as a module path, so use `node --test` with no folder argument.
